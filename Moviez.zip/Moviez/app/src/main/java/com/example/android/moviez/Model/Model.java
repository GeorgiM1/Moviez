package com.example.android.moviez.Model;

import java.util.ArrayList;

/**
 * Created by pc on 2/6/2018.
 */

public class Model {
    ArrayList<Movie> results;

    public ArrayList<Movie> getResults() {
        return results;
    }
}
