package com.example.android.moviez.Model;

/**
 * Created by pc on 2/26/2018.
 */

public class UserSession {
    boolean success;

    String session_id;

    public boolean isSuccess() {
        return success;
    }

    public String getSession_id() {
        return session_id;
    }
}
