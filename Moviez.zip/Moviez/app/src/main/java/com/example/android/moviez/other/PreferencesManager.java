package com.example.android.moviez.other;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;

import com.example.android.moviez.Model.Movie;
import com.google.gson.Gson;

/**
 * Created by pc on 2/12/2018.
 */

public class PreferencesManager {

    private static SharedPreferences getPreferences(Context context) {
        return context.getApplicationContext().getSharedPreferences("MySharedPreferencesFile", Activity.MODE_PRIVATE);
    }
    public static void addMovie(Movie people, Context c){
        Gson gson = new Gson();
        String mapStrnig = gson.toJson(people);
        getPreferences(c).edit().putString("people", mapStrnig).apply();
    }
    public static Movie getMovie(Context context){
        return  new Gson().fromJson(getPreferences(context).getString("people", ""), Movie.class);
    }

}
