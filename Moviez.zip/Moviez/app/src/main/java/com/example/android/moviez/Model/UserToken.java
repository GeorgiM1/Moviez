package com.example.android.moviez.Model;

/**
 * Created by pc on 2/26/2018.
 */

public class UserToken {
    boolean successs;
    String request_token;

    public boolean isSuccesss() {
        return successs;
    }

    public String getRequest_token() {
        return request_token;
    }
}
