package com.example.android.moviez.other;

/**
 * Created by pc on 2/12/2018.
 */

public class Constants {
    public static String imgLink = "https://image.tmdb.org/t/p/w500";
}
