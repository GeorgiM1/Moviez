package com.example.android.moviez.Api;

import com.example.android.moviez.Model.AuthToken;
import com.example.android.moviez.Model.GuestUser;
import com.example.android.moviez.Model.Model;
import com.example.android.moviez.Model.MovieCredits;
import com.example.android.moviez.Model.PeopleDetails;
import com.example.android.moviez.Model.PeopleModel;
import com.example.android.moviez.Model.UserSession;
import com.example.android.moviez.Model.UserToken;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Path;
import retrofit2.http.Query;

/**
 * Created by pc on 2/8/2018.
 */

public interface ApiService {
    @GET("movie/now_playing")
    Call<Model> getNowPlaying ();

    @GET("movie/popular")
    Call<Model> getPopular ();

    @GET("movie/top_rated")
    Call<Model> getTopRated ();

    @GET("movie/upcoming")
    Call<Model> getUpcoming ();

    @GET ("search/movie")
    Call<Model> getSearchedMovie (@Query("query") String term);

    @GET ("person/popular")
    Call<PeopleModel> getPeople ();

    @GET ("search/person")
    Call<PeopleModel> getSearchedPeople (@Query("query") String query);

    @GET("movie/{id}/credits")
    Call<MovieCredits> getMovieCredits (@Path("id") int id);

    @GET("person/{id}")
    Call<PeopleDetails> getPeopleDetails (@Path("id") int id);

    @GET("authentication/token/new")
    Call<AuthToken> getToken ();

    @GET("authentication/token/validate_with_login")
    Call<UserToken> getUserToken (@Query("username") String username,
                                  @Query("password") String password,
                                  @Query("request_token") String request_token);
    @GET ("authentication/guest_session/new")
    Call<GuestUser> getGuest ();

    @GET("authentication/session/new")
    Call<UserSession> getUserSession (@Query("request_token") String request_token);

}
