package com.example.android.moviez.Api;

/**
 * Created by pc on 2/8/2018.
 */

public class ApiConstants {
        public static final String KEY = "api_key=adc8cf4fe60c9e74d4260be93bdda240s";
}
